#ifndef WANDA_GPIO_H
#define WANDA_GPIO_H

void GpioSet(uint16_t data);
int GpioInit();


#endif
